import {
  Address,
  crypto,
  Bytes,
  ethereum,
  log,
  ByteArray,
  BigInt,
  ValueKind,
  Value,
  json,
  JSONValueKind,
  TypedMap,
  JSONValue,
} from "@graphprotocol/graph-ts";
import {
  DecodedInput,
  Log,
  Parameters,
  Transaction,
  TransactionReceipt,
} from "../../generated/schema";
import { handleAccount } from "./accounts";
import { ABI_FUNCTION_DEFINITIONS, ABI } from "../utils/constants";
import { Method } from "../types/function";

export function handleTransaction(event: ethereum.Event): Transaction {
  let txEntity = Transaction.load(event.transaction.hash);

  if (txEntity == null) {
    txEntity = new Transaction(event.transaction.hash);
    txEntity.id = event.transaction.hash;
    txEntity.hash = event.transaction.hash;
    txEntity.block = event.block.number.toString();
    txEntity.timestamp = event.block.timestamp;
    txEntity.from = handleAccount(event.transaction.from);
    if (event.transaction.to !== null) {
      txEntity.to = handleAccount(event.transaction.to as Address);
    } else {
      txEntity.to = null;
    }
    txEntity.decodedInput = decodeTxInputData(event.transaction);
    txEntity.value = event.transaction.value;
    txEntity.gasPrice = event.transaction.gasPrice;
    txEntity.gasLimit = event.transaction.gasLimit;
    txEntity.nonce = event.transaction.nonce;
    txEntity.inputData = event.transaction.input;
    txEntity.save();
  }
  return txEntity as Transaction;
}

export function handleTransactionReceipt(event: ethereum.Event): void {
  log.info("handleTransactionReceipt: {}", [event.transaction.hash.toString()]);
  let txEntity = TransactionReceipt.load(event.transaction.hash);
  if (txEntity == null) {
    txEntity = new TransactionReceipt(event.transaction.hash);
    txEntity.id = event.transaction.hash;
    let receipt = event.receipt as ethereum.TransactionReceipt | null;
    if (receipt !== null && receipt.logs !== null && receipt.logs.length) {
      txEntity.logs = handleTransactionLog(receipt.logs);
      txEntity.status = receipt.status;
      txEntity.gasUsed = receipt.gasUsed;
      txEntity.cumulativeGasUsed = receipt.cumulativeGasUsed;
      txEntity.contractAddress = receipt.contractAddress;
      txEntity.logsBloom = receipt.logsBloom;
      txEntity.root = receipt.root;
    }
    txEntity.transaction = event.transaction.hash;
    txEntity.blockHash = event.block.hash;
    txEntity.blockNumber = event.block.number;

    txEntity.save();
  }
}

export function handleTransactionLog(receiptLogs: ethereum.Log[]): Bytes[] {
  let Logs: Bytes[] = [];
  for (let i = 0; i < receiptLogs.length; i++) {
    let receiptLog = receiptLogs[i];
    let id = receiptLog.transactionHash.concatI32(receiptLog.logIndex.toI32());

    log.info("handleTransactionLogs: {}", [id.toHexString()]);

    let logEntity = Log.load(id);
    if (logEntity == null) {
      logEntity = new Log(id);
      logEntity.id = id;
      logEntity.transactionReceipt = receiptLog.transactionHash;
      logEntity.transactionHash = receiptLog.transactionHash;
      logEntity.blockNumber = receiptLog.blockNumber;
      logEntity.blockHash = receiptLog.blockHash;
      logEntity.address = receiptLog.address;
      logEntity.data = receiptLog.data;
      logEntity.topics = receiptLog.topics;
      logEntity.logIndex = receiptLog.logIndex;
      logEntity.transactionLogIndex = receiptLog.transactionLogIndex;
      logEntity.logType = receiptLog.logType;
      // logEntity.removed = receiptLog.removed ?? false;
      logEntity.save();
    }
    Logs.push(id);
  }
  return Logs;
}

const decodeTxInputData = (tx: ethereum.Transaction): Bytes => {
  let methodSelectors = getFunctionSelectors(); // First 4 bytes (8 hex chars)
  let methodSignature = tx.input.toHexString().slice(0, 10);
  let method = tx.input.toHexString().slice(10, 74);
  let params = tx.input.toHexString().slice(74);
  let decodedInputData = DecodedInput.load(tx.hash);
  let input = tx.input.toHexString().slice(10);

  log.info("Method: {} {} {}", [methodSignature, method, params]);

  for (let i = 0; i < methodSelectors.length; i++) {
    log.info("Comparing function signature: {} {} {} {}", [
      methodSignature,
      methodSelectors[i].methodName,
      methodSelectors[i].methodSelector,
      methodSelectors[i].parameterTypes,
    ]);

    if (methodSelectors[i].methodSelector == methodSignature) {
      log.info(
        "method id matched: {} with selector: {}, input data: {} {} {}",
        [
          methodSignature,
          methodSelectors[i].methodSelector,
          input,
          methodSelectors[i].parameterTypes,
          methodSelectors[i].methodName,
        ]
      );
      if (
        methodSelectors[i].parameterTypes.includes("uint256[]") ||
        methodSelectors[i].parameterTypes.includes("address[]") ||
        methodSelectors[i].parameterTypes.includes("bytes") ||
        methodSelectors[i].parameterTypes.includes("bytes[]") ||
        methodSelectors[i].parameterTypes.includes("bytes32[]")
      ) {
        log.info("dynamic data found: {}", [methodSelectors[i].parameterTypes]);
        input =
          "0000000000000000000000000000000000000000000000000000000000000020" +
          input;
      }
      // let data = txInput.subarray(4); // Extract the rest of the input data
      log.info("Decoding input data: {} for function selector {}", [
        `(${methodSelectors[i].parameterTypes})`,
        input,
      ]);
      // Decode the parameters based on the function signature
      let decoded = ethereum.decode(
        `(${methodSelectors[i].parameterTypes})`,
        Bytes.fromHexString(input)
      );
      if (decoded !== null) {
        logDecodedValues(
          decoded,
          methodSelectors[i].parameterTypes,
          methodSelectors[i].methodName,
          tx
        );
      }

      if (decodedInputData == null) {
        decodedInputData = new DecodedInput(tx.hash);
        decodedInputData.id = tx.hash;
        decodedInputData.method = methodSelectors[i].methodName;
        decodedInputData.parameters = tx.hash;
        decodedInputData.save();
      }
      return decodedInputData.id;
    }
  }
  if (decodedInputData == null) {
    decodedInputData = new DecodedInput(tx.hash);
    decodedInputData.id = tx.hash;
    decodedInputData.method = methodSignature;
    decodedInputData.save();
    return decodedInputData.id;
  }
  return decodedInputData.id;
};

export function getFunctionSelectors(): Array<Method> {
  let functionSelectors: Array<Method> = [];

  // for (let i = 0; i < ABI.length; i++) {
  //   let methodSignature = "";
  //   let methodInputs = "";
  //   let byteArray = ByteArray.fromUTF8(methodSignature);
  //   let hash = crypto.keccak256(byteArray);
  //   let methodSelector = hash.toHexString().slice(0, 10); // Extract the first 4 bytes (8 hex chars)
  //   functionSelectors.push(
  //     new Method(
  //       methodSignature.split("(")[0],
  //       methodSignature.split("(")[1].split(")")[0],
  //       methodSignature,
  //       methodSelector,
  //       methodInputs
  //     )
  //   );
  //   log.info("Function selector for {}: {} {} {}", [
  //     methodSignature.split("(")[0],
  //     methodSignature.split("(")[1].split(")")[0],
  //     methodSignature,
  //     methodSelector,
  //     methodInputs,
  //   ]);
  // }

  return functionSelectors;
}

function logDecodedValues(
  value: ethereum.Value,
  methodParams: string,
  methodName: string,
  tx: ethereum.Transaction
): void {
  log.info("methodName methodParams: {} {} ", [methodName, methodParams]);
  // log.info("value: {}", [value.displayData()]);
  let paramTypes = methodParams.split(",");
  log.info("Decoded values: {} ", paramTypes);
  const tuple = value.toTuple();

  log.info("Tuple: {}", [tuple.length.toString()]);
  for (let i = 0; i < tuple.length; i++) {
    let param = tuple.at(i);
    log.info("Param type: {}", [paramTypes[i]]);
    let jsonObject = new TypedMap<string, Value>();

    // Add key-value pairs to the JSON object
    if (paramTypes[i] == "uint256") {
      log.info("Param {} (uint256): {}", [
        i.toString(),
        param.toBigInt().toString(),
      ]);
      jsonObject.set(i.toString(), Value.fromBigInt(param.toBigInt()));
    } else if (paramTypes[i] == "uint64") {
      log.info("Param {} (uint64): {}", [
        i.toString(),
        param.toBigInt().toString(),
      ]);
      jsonObject.set(i.toString(), Value.fromBigInt(param.toBigInt()));
    } else if (paramTypes[i] == "int256") {
      log.info("Param {} (int256): {}", [
        i.toString(),
        param.toBigInt().toString(),
      ]);
      jsonObject.set(i.toString(), Value.fromBigInt(param.toBigInt()));
    } else if (paramTypes[i] == "address") {
      log.info("Param {} (address): {}", [
        i.toString(),
        param.toAddress().toHexString(),
      ]);
      jsonObject.set(i.toString(), Value.fromAddress(param.toAddress()));
    } else if (paramTypes[i] == "bytes32") {
      log.info("Param {} (bytes32): {}", [
        i.toString(),
        param.toBytes().toHexString(),
      ]);
      jsonObject.set(i.toString(), Value.fromBytes(param.toBytes()));
    } else if (paramTypes[i] == "bool") {
      log.info("Param {} (bool): {}", [
        i.toString(),
        param.toBoolean().toString(),
      ]);
      jsonObject.set(i.toString(), Value.fromBoolean(param.toBoolean()));
    } else if (paramTypes[i] == "string") {
      log.info("Param {} (string): {}", [i.toString(), param.toString()]);
      jsonObject.set(i.toString(), Value.fromString(param.toString()));
    } else if (paramTypes[i] == "bytes") {
      log.info("Param {} (bytes): {}", [
        i.toString(),
        param.toBytes().toHexString(),
      ]);
      jsonObject.set(i.toString(), Value.fromBytes(param.toBytes()));
    } else if (paramTypes[i] == "uint256[]") {
      log.info("Param {} (uint256[]): {}", [
        i.toString(),
        param
          .toBigIntArray()
          .map<string>((value) => value.toString())
          .join(", "),
      ]);
      jsonObject.set(
        i.toString(),
        Value.fromBigIntArray(param.toBigIntArray())
      );
    } else if (paramTypes[i] == "int256[]") {
      log.info("Param {} (int256[]): {}", [
        i.toString(),
        param
          .toBigIntArray()
          .map<string>((value) => value.toString())
          .join(", "),
      ]);
      jsonObject.set(
        i.toString(),
        Value.fromBigIntArray(param.toBigIntArray())
      );
    } else if (paramTypes[i] == "address[]") {
      log.info("Param {} (address[]): {}", [
        i.toString(),
        param
          .toAddressArray()
          .map<string>((value) => value.toHexString())
          .join(", "),
      ]);
      jsonObject.set(
        i.toString(),
        Value.fromAddressArray(param.toAddressArray())
      );
    } else if (paramTypes[i] == "bool[]") {
      log.info("Param {} (bool[]): {}", [
        i.toString(),
        param
          .toBooleanArray()
          .map<string>((value) => value.toString())
          .join(", "),
      ]);
      jsonObject.set(
        i.toString(),
        Value.fromBooleanArray(param.toBooleanArray())
      );
    } else if (paramTypes[i] == "bytes32[]") {
      log.info("Param {} (bytes32[]): {}", [
        i.toString(),
        param
          .toBytesArray()
          .map<string>((value) => value.toHexString())
          .join(", "),
      ]);
      jsonObject.set(i.toString(), Value.fromBytesArray(param.toBytesArray()));
    } else if (paramTypes[i].startsWith("tuple")) {
      log.info("Param {} (tuple): {}", [i.toString()]);
      // let tupleParam = param.toTuple();
      // You can recursively log tuple elements by calling this function again
      logDecodedValues(param, extractTupleTypes(paramTypes[i]), methodName, tx);
    }
    let entity = Parameters.load(tx.hash);

    if (entity == null) {
      entity = new Parameters(tx.hash);
    }
    log.info("JSON Object: {}", [stringifyMap(jsonObject)]);
    entity.metadata = stringifyMap(jsonObject);
    entity.save();
  }
}

function stringifyMap(map: TypedMap<string, Value>): string {
  let result = "{";
  let keys = map.entries;

  for (let i = 0; i < keys.length; i++) {
    let key = keys[i].key;
    let value = stringifyValue(map.get(key) as Value);
    result += `"${key}":${value}`;
    log.info("Key: {} Value: {}", [key, value]);
    if (i < keys.length - 1) {
      result += ",";
    }
  }

  result += "}";
  return result;
}

function stringifyValue(value: Value): string {
  if (value.kind == ValueKind.STRING) {
    return `"${value.toString()}"`;
  } else if (value.kind == ValueKind.INT) {
    return value.toI64().toString();
  } else if (value.kind == ValueKind.BOOL) {
    return value.toBoolean() ? "true" : "false";
  } else if (value.kind == ValueKind.BIGINT) {
    return value.toBigInt().toString();
  } else if (value.kind == ValueKind.ARRAY) {
    let arr = value.toArray();
    let result = "[";
    for (let i = 0; i < arr.length; i++) {
      result += stringifyValue(arr[i]);
      if (i < arr.length - 1) {
        result += ",";
      }
    }
    result += "]";
    return result;
  } else if (value.kind == ValueKind.NULL) {
    return "null";
  }
  return "null";
}

// Helper function to extract tuple types from the parameter string (e.g., tuple(uint256,address) -> uint256,address)
function extractTupleTypes(tupleType: string): string {
  let start = tupleType.indexOf("(") + 1;
  let end = tupleType.lastIndexOf(")");
  return tupleType.substring(start, end);
}
