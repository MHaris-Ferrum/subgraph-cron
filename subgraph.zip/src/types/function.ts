export class Method {
  methodName: string;
  parameterTypes: string;
  methodSignature: string;
  methodSelector: string;
  methodInputs: string;
  constructor(
    methodName: string,
    parameterTypes: string,
    methodSignature: string,
    methodSelector: string,
    methodInputs: string
  ) {
    this.methodName = methodName;
    this.parameterTypes = parameterTypes;
    this.methodSignature = methodSignature;
    this.methodSelector = methodSelector;
    this.methodInputs = methodInputs;
  }
}
